﻿
using System;
using Wisej.Web;
using System.IO;
using System.Drawing;

namespace eSignatureSample
{
    public partial class TopazHtmlDialog : Form
    {
        public string SessionVariable;
        private string _signatureID;
        private int _height;
        private int _width;
        public TopazHtmlDialog( int height, int width)
        {
            InitializeComponent();
            //_signatureID = signatureID;
            this.ControlBox = false;
            _height = height;
            _width = width;
            this._htmlBoxTopaz.HtmlSource = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"Resources\HtmlContent.txt");
        }
        
        private int Height { get => _height; set => _height = value; }
        private int Width { get => _width; set => _width = value; }
        private void _btnOKTopazHtml_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
