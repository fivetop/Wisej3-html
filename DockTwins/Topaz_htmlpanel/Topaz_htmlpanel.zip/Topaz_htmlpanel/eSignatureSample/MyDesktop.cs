﻿using System;
using Wisej.Web;

namespace eSignatureSample
{
    public partial class MyDesktop : Desktop
    {
        public MyDesktop()
        {
            InitializeComponent();
        }
    }
}
