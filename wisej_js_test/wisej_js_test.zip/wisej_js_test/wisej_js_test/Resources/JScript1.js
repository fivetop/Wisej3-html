﻿function show() {
    alert("Shree Gajanan Maharaj Ki Jay...!");
}
